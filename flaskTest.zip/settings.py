import json
class EnvConfig:
    DEBUG=True
    SECRET_KEY='asfda8r9s'
class Config:
    PORT=5000
    HOST='0.0.0.0'
    ORIGINAL_MAP={'White':{'K':'e1','Q':'d1','B1':'c1','B2':'f1','N1':'b1','N2':'g1','R1':'a1','R2':'h1','P1':'a2','P2':'b2','P3':'c2','P4':'d2','P5':'e2','P6':'f2','P7':'g2','P8':'h2'},'Black':{'K':'d1','Q':'e1','B1':'c1','B2':'f1','N1':'b1','N2':'g1','R1':'a1','R2':'h1','P1':'a2','P2':'b2','P3':'c2','P4':'d2','P5':'e2','P6':'f2','P7':'g2','P8':'h2'}}
    DEFAULT_STATUS="rnbqkbnr/pppppppp/8o/8o/8o/8o/PPPPPPPP/RNBQKBNR?w"
    #DEFAULT_STATUS="rnbqkbnr/pppppppp/8o/8o/4oP3o/8o/PPPP1oPPP/RNBQKBNR/?w"