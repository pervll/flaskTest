# python environment 3.11.8
### Standard map like this: "1r1n1b1q1k2b2n2r/1p2p3p4p5p6p7p8p/8o/8o/8o/8o/1P2P3P4P5P6P7P8P/1R1N1B1Q1K2B2N2R?w"
### 吃过路兵 王车易位等数据可以放在后面用?分隔